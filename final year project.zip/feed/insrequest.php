<?php
$servername = "localhost";
$user = "root";
$pass = "";
$dbname = "fchostupdates";
$con = mysqli_connect($servername, $user, $pass, $dbname);
if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name = $_POST['name'];
$contact = $_POST['contact'];
$request = $_POST['request'];
$address = $_POST['address'];
$sql = "INSERT INTO help (name, contact, request, address)
VALUES ('$name', '$contact', '$request', '$address')";
if(mysqli_query($con, $sql)){
    echo "Records inserted successfully.";
    header('Location: request.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
}

mysqli_close($con);
?> $con->sql($sql);