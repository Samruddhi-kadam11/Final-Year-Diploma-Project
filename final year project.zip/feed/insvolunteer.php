<?php
$servername = "localhost";
$user = "root";
$pass = "";
$dbname = "fchostupdates";
$con = mysqli_connect($servername, $user, $pass, $dbname);
if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name = $_POST['name'];
$contact = $_POST['contact'];
$work = $_POST['work'];
$sql = "INSERT INTO volunteer (name, contact, work)
VALUES ('$name', '$contact', '$work')";
if(mysqli_query($con, $sql)){
    echo "Records inserted successfully.";
    header('Location: volunteer.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
}

mysqli_close($con);
?> $con->sql($sql);